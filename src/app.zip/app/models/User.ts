export class User{

  id: string;
  firstName: string;
  lastName: string;
  password: string;
  email: string;
  location: string;
  gender: string;
  phone: string;
}
